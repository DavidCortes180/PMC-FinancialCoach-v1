/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

/**
 *
 * @author user
 */
public class CalculadoraLogic 
{
  
    public double calculoContado(double CoutaInicial)
    {
        return CoutaInicial;
    }
    
    public double calculoCredito(double TasaInteresMensual,int NumeroMesesPagarCredito)
    {
        return TasaInteresMensual*NumeroMesesPagarCredito;
    }
    
    public double calculoLeasing(double TasaInteresMensuaLeasing, int NumeroMesosUsoLeasing)
    {
        return TasaInteresMensuaLeasing*NumeroMesosUsoLeasing;
    }
}
